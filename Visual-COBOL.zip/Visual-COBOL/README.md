# Visual-COBOL
This is version 6.0 for linux
